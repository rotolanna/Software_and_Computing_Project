#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ class EventoFin+;
#pragma link C++ class FiberHit+;
#pragma link C++ class EventData+;
#pragma link C++ class Geometry+;
#pragma link C++ class Track+;
#pragma link C++ class Wire+;
#pragma link C++ class MinQua+;
#pragma link C++ class OptPhoton+;
#endif
